import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner entrada = new Scanner (System.in);
    
    double TotalGastoPeloCliente
      int NumParcelas, OpcaoDePagamento

  System.out.println("Insira o Total Gasto")
TotalGastoPeloCliente=entrada.nextdouble();
   
    while(TotalGastoPeloCliente!=-1);
    {
      System.out.println("Mostrar as formas de Pagamentos\n 1-A vista com 10% de Desconto\n 2-Parcelado 2X\n 3- Parcelado de 3 a 6X com 3% de Juros ao mês."
      )
      OpcaoDePagamento=entrada.nextInt();
      Switch(OpcaoDePagamento);
      {
        case 1: System.out.println("Valor Total da Compra em R$"+TotalGastoPeloCliente*0.9 );
        brake;

        case 2: System.out.println("Valor Total da Compra em R$"+TotalGastoPeloCliente+",em duas parcelas de:"+TotalGastoPeloCliente/2 );
        brake;

        case 3:
        If (TotalGastoPeloCliente>=500)
          {System.out.println("Escolha o número de Parcelas");
          NumParcelas=entrada.nextInt();
            if (NumParcelas>=3 & <=6);
            
            {System.out.printf("Valor Total Parcelado: %.2f, %d parcelados de R$ %.2f\n",TotalGastoPeloCliente*1.03, NumParcelas, (TotalGastoPeloCliente*1.03)/NumParcelas);
              }
            
              else {System.out.println("Número de Parcelas Inválido");
                } 
      }
        else {System.out.println("Escolha outra forma de Pagamento"); 
          }
        brake;
        default:

          System.out.println("Insira o Total Gasto");
        
   TotalGastoPeloCliente = entrada.nextDouble(); 
  }
}
    }
}